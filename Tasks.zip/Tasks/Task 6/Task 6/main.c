//
//  main.c
//  Task 6
//
//  Created by Deep on 6/24/19.
//  Copyright © 2019 Deep. All rights reserved.
//


#include <stdio.h>
#include <math.h>

int main() {
    
    int num = 0;
    int digits [10];
    int c = 0;
    int i = 0;
    int sum = 0;
    printf("Enter a number: \n");
    scanf("%d",&num);
    
    while (num>0) {
        digits [c] = num%10;

        num = num/10;
        c++;
    };
    //printf("No. of digits %d.\n",c);

    
    for (i = 0; i<c; i++) {
        //printf("%d", digits[i]);
        sum = sum + pow(digits[i],c);
    }
    printf("\n");
   // printf("The armstrong value is %d\n",sum);
    if (num == sum) {
        printf("The entered number %d is an Armstrong Number.\n",num);
    
    } else
        printf("The entered number %d is not an Armstrong Number.\n",num);
    
    
}
