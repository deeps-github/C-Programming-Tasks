//
//  main.c
//  Task 10
//
//  Created by Deep on 6/24/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>

int main() {
   /* WRITE A C PROGRAM TO PRINT THE GIVEN PYRAMID(CLICK TO SEE THE PYRAMID).
    
    12345
    
    1234
    
    123
    
    12
    
    1 */
    
    int i = 0;
    for (i = 5; i>=0; i--) {
        printf(<#const char *restrict, ...#>)
    }
}
