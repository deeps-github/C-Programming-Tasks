//
//  main.c
//  Task 5
//
//  Created by Deep on 6/24/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>

int main() {

    int num = 0;
    printf("Enter a number: \n");
    scanf("%d",&num);
    
    while (num>9) {
        printf("%d",num%10);
        num = num/10;
    };
    printf("%d\n",num);
}
