//
//  main.c
//  Task 3
//
//  Created by Deep on 6/24/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>

main() {
    int sub1 = 0, sub2 = 0, sub3 = 0, sum=0;
    double avg = 0;
    printf("Enter marks for Subject 1: \n");
    scanf("%d",&sub1);
    printf("Enter marks for Subject 2: \n");
    scanf("%d",&sub2);
    printf("Enter marks for Subject 3: \n");
    scanf("%d",&sub3);
    
    sum = sub1 + sub2 + sub3;
    avg = (sum)/3;
    printf("\nThe sum of the marks is %d.\n",sum);
    printf("The average of the marks is %f.\n",avg);
    
}
