//
//  main.c
//  Task 8
//
//  Created by Deep on 6/24/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>

/* WRITE A C PROGRAM TO READ AN INTEGER AND PRINT ITS MULTIPLICATION TABLE.
 
 Sample Input : 5
 
 Sample Output :
 
 5 * 1 = 5
 
 5 * 2 = 10
 
 5 * 3 = 15
 
 ...
 
 ...
 
 5 * 10 = 50
 */

int main() {
    int num = 0;
    int i = 0;
    printf("Enter the number for which you want a multiplication table: \n");
    scanf("%d",&num);
    
    for (i=1; i<=10; i++) {
        printf("%d X %d = %d\n",num, i, num * i);
    };
}
