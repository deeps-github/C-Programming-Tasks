//
//  main.c
//  Task 4
//
//  Created by Deep on 6/24/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>
//WRITE A C PROGRAM TO READ THE FIRST NAME AND THE LAST NAME OF THE USER IN 2 DIFFERENT VARIABLES, COMBINE THEM, AND DISPLAY THEIR FULL NAME USING A SINGLE STRING
main() {
    char fname[10], lname[10];
    printf("Please enter your first name: \n");
    scanf("%s",&fname);
    printf("Please enter your last name: \n");
    scanf("%s",&lname);
    
    printf("%s",strcat(&fname, &lname));
    
}
