//
//  main.c
//  Task 1
//
//  Created by Deep on 6/11/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>

 main() {
   
     printf("Please enter your Name: \n");
     char fname[10] ;
     scanf("%s",&fname);
     
     printf("Please enter your Age: \n");
     int age = 0;
     scanf("%d", &age);
     
     printf("Please enter your Phone Number (Max 10 Digits): \n");
    char pnum[10];
     scanf( "%s",&pnum);
     
     printf("Your name is %s.\nYour age is %d.\nYour Phone Number is %s.\n",fname,age,pnum);
     
     
}
