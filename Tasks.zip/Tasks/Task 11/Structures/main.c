//
//  main.c
//  Structures
//
//  Created by Deep on 6/21/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>

struct book book_read ();

struct book {
    char title [20];
    char author [20];
    char genre [20];
};

int main() {
    struct book bkk;
    bkk = book_read();
    output(bkk);
}

struct book book_read (){
    struct book b1;
    printf("Please enter the title of the book (No Spaces) :\n");
    scanf("%s",&b1.title);
    printf("Please enter the Author's name (No Spaces) :\n");
    scanf("%s",&b1.author);
    printf("Please enter the Genre of the book (No Spaces) :\n");
    scanf("%s",&b1.genre);
    return b1;
}

int output (struct book bk) {
    printf("\nThe Title of the Book is %s", bk.title);
    printf("\nThe Author of the Book is %s", bk.author);
    printf("\nThe Genre of the Book is %s\n",bk.genre);
     return 0;
}
