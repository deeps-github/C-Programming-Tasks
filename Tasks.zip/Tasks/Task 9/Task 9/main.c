//
//  main.c
//  Task 9
//
//  Created by Deep on 6/24/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>

int main() {
    int num = 0;
    int i=0;
    int factorial = 1;
    printf("Enter the number for which you want to find its factorial: \n");
    scanf("%d",&num);
    
    for (i=1; i<=num; i++) {
        factorial = factorial * i;
    }
    printf("The factorial of %d is %d. \n",num,factorial);
}
