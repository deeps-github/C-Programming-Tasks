//
//  main.c
//  Task 12
//
//  Created by Deep on 7/12/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>

 main() {
     int choice = 0;
     int a = 0;
     float tempC=0, tempF=0;
     while (a == 0) {
         printf("Select the operation you wish to perform:\n1.ºC to ºF\n2.ºF to ºC\n3.Exit\n");
         scanf("%d",&choice);
         
         switch (choice) {
             case 1:
                 printf("Enter the temperature in º Celsius: \n");
                 scanf("%f",&tempC);
                 tempF = (tempC * 9)/5 + 32;
                 printf("The temparature in Fahreheit is %fºF.\n", tempF);
                 break;
                 
             case 2:
                 printf("Enter the temperature in º Fahrenheit: \n");
                 scanf("%f",&tempF);
                 tempC = (tempF -32)/ 9 * 5 ;
                 printf("The temparature in Celsius is %fºC.\n", tempC);
                 break;
             case 3:
                  a = 1;
                 break;
             default:
                 printf("Error");
                 break;
     }
     
     
     }
    return 0;
}
