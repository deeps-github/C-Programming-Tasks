//
//  main.c
//  Task 7
//
//  Created by Deep on 6/24/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>
#include <string.h>


main() {
    char word [20];
    int j = 0;
    char c1,c2;
    
    printf("Enter a word: \n");
    scanf("%s",&word);
    
    for (int i = 0; i<=strlen(word)/2; i++) {
        j = strlen(word) - i-1;
        c1 = word[j];
        c2 = word[i];
        if (strcmp(&c1,&c2)<0) {
        }
        else
        {
            printf("%s is NOT a PALINDROME\n\n",word);
            break;
        }
    };
    
    if (strcmp(&c1,&c2)<0) {
        
        printf("%s is a PALINDROME\n\n",word);
    }
    }
    

