//
//  main.c
//  Task 2
//
//  Created by Deep on 6/24/19.
//  Copyright © 2019 Deep. All rights reserved.
//

#include <stdio.h>

main() {
    /*
     WRITE A C PROGRAM TO TAKE THE TEMPERATURE IN CELSIUS AND CONVERT IT TO FAHRENHEIT AND DISPLAY IT BACK.
     
     *Tip -> Use this formula -> Celsius = 5 * (Fahrenheit - 32)/9
     
     PS -> Use the 'FLOAT' data type
     */
    float tempC=0, tempF=0;
    printf("Enter the temperature in º Celsius: \n");
    scanf("%f",&tempC);
    tempF = (tempC * 9)/5 + 32;
    printf("The temparature in Fahreheit is %fºF.\n", tempF);
}
